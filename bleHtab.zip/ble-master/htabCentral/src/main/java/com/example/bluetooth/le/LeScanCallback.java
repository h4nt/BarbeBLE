package com.example.bluetooth.le;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.os.Build;
import android.util.Log;

import com.horanet.bleutils.ByteArrays;

import static com.example.bluetooth.le.DeviceScanActivity.APP_NAME;

/**
 * Created by H4 on 20/03/2020.
 */
public class LeScanCallback implements BluetoothAdapter.LeScanCallback {
    private final static String TAG = APP_NAME + LeScanCallback.class.getSimpleName();

    private BluetoothGatt mBluetoothGatt;
    private DeviceScanActivity deviceScanActivity;
    private LeDeviceListAdapter leDeviceListAdapter;
    private String mDeviceAddress = "";

    public LeScanCallback(DeviceScanActivity deviceScanActivity, LeDeviceListAdapter leDeviceListAdapter) {
        this.deviceScanActivity = deviceScanActivity;
        this.leDeviceListAdapter = leDeviceListAdapter;
    }

    @Override
    public void onLeScan(final BluetoothDevice device, int rssi, final byte[] scanRecord) {
        deviceScanActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                leDeviceListAdapter.addDevice(device);
                leDeviceListAdapter.notifyDataSetChanged();
            }
        });

        Log.d(TAG, "scanned device: " + device.getAddress());
        Log.d(TAG, "scanned rssi: " + rssi);
        String record = StringUtils.removeTrailingZeroes(ByteArrays.byte2HexString(scanRecord));
        Log.d(TAG, "scanned scanRecord: " + record);
        //TODO: Do proper scanRecord parsing !!!
        String serial = record.substring(record.length() - 16 * 2);
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < serial.length(); i += 2) {
            String str = serial.substring(i, i + 2);
            output.append((char) Integer.parseInt(str, 16));
        }
        Log.d(TAG, "======== received serial: " + output.toString().trim() + " my serial " + Build.SERIAL);


        if (!mDeviceAddress.equals(device.getAddress())) {
            mDeviceAddress = device.getAddress();
            // We want to directly connect to the device, so we are setting the autoConnect
            // parameter to false.
            mBluetoothGatt = device.connectGatt(deviceScanActivity.getApplicationContext(), false, deviceScanActivity.mGattCallback);
            Log.d(TAG, "Trying to create a new connection: " + mDeviceAddress);
        }
    }
}
