package com.example.bluetooth.le;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothProfile;
import android.util.Log;

import com.horanet.bleutils.ByteArrays;

import static com.example.bluetooth.le.DeviceScanActivity.APP_NAME;

public class HtabBluetoothGattCallback extends BluetoothGattCallback {
    private final static String TAG = APP_NAME + HtabBluetoothGattCallback.class.getSimpleName();
    private DeviceScanActivity deviceScanActivity;

    public HtabBluetoothGattCallback(DeviceScanActivity activity) {
        deviceScanActivity = activity;
    }

    @Override
    public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
        if (newState == BluetoothProfile.STATE_CONNECTED) {
            Log.i(TAG, "Connected to GATT server.");
            Log.i(TAG, "Attempting to start service discovery:" +
                    gatt.discoverServices());
            //gatt.disconnect();
        } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
            Log.i(TAG, "Disconnected from GATT server.");
        }
    }

    @Override
    public void onServicesDiscovered(BluetoothGatt gatt, int status) {
        Log.w(TAG, "onServicesDiscovered received: " + status);
        deviceScanActivity.displayGattServices(gatt.getServices());
    }

    @Override
    public void onCharacteristicRead(BluetoothGatt gatt,
                                     BluetoothGattCharacteristic characteristic,
                                     int status) {
        Log.w(TAG, "onCharacteristicRead received: " + status);

    }

    @Override
    public void onCharacteristicChanged(BluetoothGatt gatt,
                                        BluetoothGattCharacteristic characteristic) {
        Log.w(TAG, "onCharacteristicRead received: " + ByteArrays.byte2HexString(characteristic.getValue()));
    }
}
