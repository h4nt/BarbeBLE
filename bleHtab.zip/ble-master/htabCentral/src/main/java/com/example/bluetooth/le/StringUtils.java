package com.example.bluetooth.le;

public class StringUtils {
    public static String removeTrailingZeroes(String s) {
        StringBuilder sb = new StringBuilder(s);
        while (sb.length() > 2 && sb.charAt(sb.length() - 1) == '0' && sb.charAt(sb.length() - 2) == '0') {
            sb.setLength(sb.length() - 2);
        }
        return sb.toString();
    }
}
