package com.example.android.bluetoothadvertisements;

import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattServer;
import android.bluetooth.BluetoothGattServerCallback;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.util.Log;

import com.horanet.bleutils.AllGattCharacteristics;
import com.horanet.bleutils.AllGattServices;
import com.horanet.bleutils.ByteArrays;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.bluetooth.BluetoothProfile.STATE_CONNECTED;
import static com.example.android.bluetoothadvertisements.MainActivity.APP_NAME;
import static com.horanet.bleutils.AllGattServices.HEART_RATE_MEASUREMENT;

/**
 * Created by H4 on 16/03/2020.
 */
public class MyLeGattServerCb extends BluetoothGattServerCallback {
    private static final String TAG = APP_NAME + MyLeGattServerCb.class.getSimpleName();
    private Activity activity;
    private LeDeviceListAdapter leDeviceListAdapter;
    private BluetoothGattServer bluetoothGattServer;
    private BluetoothGatt mBluetoothGatt;

    private BluetoothManager bluetoothManager;

    public MyLeGattServerCb(Activity mainActivity, LeDeviceListAdapter leDeviceListAdapter) {
        this.activity = mainActivity;
        this.leDeviceListAdapter = leDeviceListAdapter;
    }

    @Override
    public void onConnectionStateChange(BluetoothDevice device, int status, int newState) {
        super.onConnectionStateChange(device, status, newState);
        Log.d(TAG, "onConnectionStateChange: " + device.getAddress() + " - status " + status + " - newState " + newState);
        bluetoothManager = (BluetoothManager) activity.getSystemService(Context.BLUETOOTH_SERVICE);

        //Connecting back to #Tab Gatt server to get #Tab name, characteristics
        if (newState == BluetoothProfile.STATE_CONNECTED) {
            mBluetoothGatt = device.connectGatt(activity.getApplicationContext(), true, new BleGattCb(device));
            Log.d(TAG, "Trying to connect back to : " + device.getAddress());
        }
        leDeviceListAdapter.addDevice(device);
    }

    private class BleGattCb extends BluetoothGattCallback {
        private BluetoothDevice device;

        BleGattCb(BluetoothDevice device) {
            super();
            this.device = device;
        }

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            String intentAction;
            if (newState == STATE_CONNECTED) {
                Log.i(TAG, "Connected to GATT server.");
                Log.i(TAG, "Attempting to start service discovery:" +
                        gatt.discoverServices());
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                Log.i(TAG, "Disconnected from GATT server.");
            }


        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            Log.w(TAG, "onServicesDiscovered received: " + status);
            displayGattServices(gatt.getServices());
            mBluetoothGatt = gatt;
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic,
                                         int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                // For all other profiles, writes the data formatted in HEX.
                final byte[] data = characteristic.getValue();
                if (data != null && data.length > 0) {
                    final StringBuilder stringBuilder = new StringBuilder(data.length);
                    for (byte byteChar : data)
                        stringBuilder.append(String.format("%02X ", byteChar));
                    Log.d(TAG, "characteristic " + AllGattCharacteristics.lookup(characteristic.getUuid()) + " data " + stringBuilder.toString());
                    if (characteristic.getUuid().toString().equals(AllGattCharacteristics.DEVICE_NAME)) {
                        Log.d(TAG, "characteristic device name " + new String(data));
                        leDeviceListAdapter.updateDevice(device, new String(data));
                    }
                    if (characteristic.getUuid().toString().equals(AllGattCharacteristics.SERIAL_NUMBER_STRING)) {
                        Log.d(TAG, "characteristic device serial " + new String(data));
                        leDeviceListAdapter.updateDeviceSerial(device, new String(data));
                    }
                }
            }
            //https://android.googlesource.com/platform/external/bluetooth/bluedroid/+/android-5.1.0_r1/stack/include/gatt_api.h#57
            Log.w(TAG, "onCharacteristicRead received: " + status);

            readBleChar();
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,
                                            BluetoothGattCharacteristic characteristic) {
            Log.w(TAG, "onCharacteristicRead received: " + ByteArrays.byte2HexString(characteristic.getValue()));
        }
    }

    ;

    // Demonstrates how to iterate through the supported GATT Services/Characteristics.
// In this sample, we populate the data structure that is bound to the ExpandableListView
// on the UI.
    private void displayGattServices(List<BluetoothGattService> gattServices) {
        if (gattServices == null) return;
        String uuid = null;
        String unknownServiceString = activity.getResources().getString(R.string.unknown_service);
        String unknownCharaString = activity.getResources().getString(R.string.unknown_characteristic);
        String unknownService = activity.getResources().getString(R.string.unknown_service);
        ArrayList<HashMap<String, String>> gattServiceData = new ArrayList<HashMap<String, String>>();
        ArrayList<ArrayList<HashMap<String, String>>> gattCharacteristicData
                = new ArrayList<ArrayList<HashMap<String, String>>>();
        ArrayList<ArrayList<BluetoothGattCharacteristic>> mGattCharacteristics = new ArrayList<ArrayList<BluetoothGattCharacteristic>>();

        readIdx = 0;

        // Loops through available GATT Services.
        for (BluetoothGattService gattService : gattServices) {
            HashMap<String, String> currentServiceData = new HashMap<String, String>();
            uuid = gattService.getUuid().toString();
            String serviceName = AllGattServices.lookup(uuid, unknownService);
            Log.i(TAG, "service name: " + serviceName);
            Log.d(TAG, "service uuid " + uuid);
            gattServiceData.add(currentServiceData);

            ArrayList<HashMap<String, String>> gattCharacteristicGroupData =
                    new ArrayList<HashMap<String, String>>();
            List<BluetoothGattCharacteristic> gattCharacteristics =
                    gattService.getCharacteristics();
            ArrayList<BluetoothGattCharacteristic> charas =
                    new ArrayList<BluetoothGattCharacteristic>();

            // Loops through available Characteristics.
            for (BluetoothGattCharacteristic gattCharacteristic : gattCharacteristics) {
                charas.add(gattCharacteristic);
                HashMap<String, String> currentCharaData = new HashMap<String, String>();
                uuid = gattCharacteristic.getUuid().toString();
                String s = AllGattCharacteristics.lookup(uuid, unknownCharaString);
                Log.i(TAG, "gattCharacteristic name: " + s);
                Log.d(TAG, "characteristic uuid " + uuid);
                gattCharacteristicGroupData.add(currentCharaData);

                //h4
                if (uuid.equals(AllGattCharacteristics.SERIAL_NUMBER_STRING)) {
                    bleChar2Reads.add(gattCharacteristic);
                }
            }
            gattCharacteristicData.add(gattCharacteristicGroupData);
        }
        readBleChar();
    }

    private ArrayList<BluetoothGattCharacteristic> bleChar2Reads = new ArrayList<>();
    private int readIdx = 0;

    private void readBleChar() {
        if (readIdx < bleChar2Reads.size()) {
            BluetoothGattCharacteristic characteristic = bleChar2Reads.get(readIdx);
            Log.d(TAG, "read gattCharacteristic " + characteristic.getUuid() + " result " + mBluetoothGatt.readCharacteristic(characteristic));
            readIdx += 1;
        } else
            mBluetoothGatt.disconnect();
    }

    /**
     * A remote client has requested to write to a local characteristic.
     *
     * <p>An application must call {@link BluetoothGattServer#sendResponse}
     * to complete the request.
     *
     * @param device         The remote device that has requested the write operation
     * @param requestId      The Id of the request
     * @param characteristic Characteristic to be written to.
     * @param preparedWrite  true, if this write operation should be queued for later execution.
     * @param responseNeeded true, if the remote device requires a response
     * @param offset         The offset given for the value
     * @param value          The value the client wants to assign to the characteristic
     */
    public void onCharacteristicWriteRequest(BluetoothDevice device, int requestId,
                                             BluetoothGattCharacteristic characteristic,
                                             boolean preparedWrite, boolean responseNeeded,
                                             int offset, byte[] value) {
    }
}
