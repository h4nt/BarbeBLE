package com.example.android.bluetoothadvertisements;

import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

// Adapter for holding devices found through scanning.
// Modified from com.example.android.bluetoothadvertisements.
class LeDeviceListAdapter extends BaseAdapter {
    private ArrayList<BluetoothDevice> mLeDevices;
    private ArrayList<String> devicesName;
    private ArrayList<String> devicesSerial;
    private LayoutInflater mInflator;
    private Activity activity;

    public LeDeviceListAdapter(Activity activity) {
        super();
        this.activity = activity;
        mLeDevices = new ArrayList<BluetoothDevice>();
        devicesName = new ArrayList<>();
        devicesSerial = new ArrayList<>();
        mInflator = activity.getLayoutInflater();
    }

    public void addDevice(BluetoothDevice device) {
        if (!mLeDevices.contains(device)) {
            mLeDevices.add(device);
            devicesName.add(device.getName());
            devicesSerial.add("serial");
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    notifyDataSetChanged();
                }
            });
        }
    }

    public BluetoothDevice getDevice(int position) {
        return mLeDevices.get(position);
    }

    public void clear() {
        mLeDevices.clear();
    }

    @Override
    public int getCount() {
        return mLeDevices.size();
    }

    @Override
    public Object getItem(int i) {
        return mLeDevices.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        // General ListView optimization code.
        if (view == null) {
            view = mInflator.inflate(R.layout.listitem_device, null);
            viewHolder = new ViewHolder();
            viewHolder.deviceAddress = (TextView) view.findViewById(R.id.device_address);
            viewHolder.deviceName = (TextView) view.findViewById(R.id.device_name);
            viewHolder.deviceSerial = (TextView) view.findViewById(R.id.device_serial);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }

        BluetoothDevice device = mLeDevices.get(i);
        final String deviceName = devicesName.get(i);
        if (deviceName != null && deviceName.length() > 0)
            viewHolder.deviceName.setText(deviceName);
        else
            viewHolder.deviceName.setText(R.string.unknown_device);
        viewHolder.deviceAddress.setText(device.getAddress());
        viewHolder.deviceSerial.setText(devicesSerial.get(i));
        return view;
    }

    public void updateDevice(BluetoothDevice device, String name) {
        if (mLeDevices.contains(device)) {
            int idx = mLeDevices.indexOf(device);
            devicesName.add(idx, name);
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    notifyDataSetInvalidated();
                }
            });
        }
    }

    public void updateDeviceSerial(BluetoothDevice device, String serial) {
        if (mLeDevices.contains(device)) {
            int idx = mLeDevices.indexOf(device);
            devicesSerial.add(idx, serial);
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    notifyDataSetInvalidated();
                }
            });
        }
    }

    public String getSerialNumber(int position) {
        return devicesSerial.get(position);
    }
/**
 * Created by h4 on 19/06/15.
 */
    static class ViewHolder {
        TextView deviceName;
        TextView deviceAddress;
        TextView deviceSerial;
    }
}
