/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.bluetoothadvertisements;

import android.app.ListActivity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattServer;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;


/**
 * Setup display fragments and ensure the device supports Bluetooth.
 * Modified from com.example.android.bluetoothadvertisements.
 */
public class MainActivity extends ListActivity {
    public static final String APP_NAME = "BLEAdvertising/";
    private static final String TAG =  APP_NAME + MainActivity.class.getSimpleName();
    public static final int REQUEST_ENABLE_BT = 1;
    public static final String DIRECTED_ADDR = "directed_addr";
    public static final String DIRECTED_DATA = "directed_data";
    private BluetoothAdapter mBluetoothAdapter;
    private LeDeviceListAdapter leDeviceListAdapter;
    private BluetoothManager bluetoothManager;
    private BluetoothGattServer bluetoothGattServer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.activity_main_title);

        bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
        leDeviceListAdapter = new LeDeviceListAdapter(this);
        setListAdapter(leDeviceListAdapter);
        String unknownCharaString = getResources().getString(R.string.unknown_characteristic);
        String unknownService = getResources().getString(R.string.unknown_service);

        // Is Bluetooth supported on this device?
        if (mBluetoothAdapter != null) {
            // Is Bluetooth turned on?
            if (mBluetoothAdapter.isEnabled()) {
                bluetoothGattServer = bluetoothManager.openGattServer(getApplicationContext(), new MyLeGattServerCb(this, leDeviceListAdapter));
            } else {
                // Prompt user to turn on Bluetooth (logic continues in onActivityResult()).
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        } else {

            // Bluetooth is not supported.
            Toast.makeText(this, R.string.bt_not_supported, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_ENABLE_BT:
                if (resultCode == RESULT_OK) {

                } else {
                    // User declined to enable Bluetooth, exit the app.
                    Toast.makeText(this, R.string.bt_not_enabled_leaving,
                            Toast.LENGTH_SHORT).show();
                    finish();
                }
            default:
                super.onActivityResult(requestCode, resultCode, data);
        }
    }

    /**
     * Returns Intent addressed to the {@code AdvertiserService} class.
     */
    private static Intent getServiceIntent(Context c, String addr, String data) {
        Intent intent = new Intent(c, AdvertiserService.class);
        if (addr != null && !addr.isEmpty() && data != null && !data.isEmpty()) {
            intent.putExtra(DIRECTED_ADDR, addr);
            intent.putExtra(DIRECTED_DATA, data);
        }
        else
            Log.e(TAG, "getServiceIntent error");
        return intent;
    }

    public void onResume() {
        super.onResume();
        startAdvertising(null, null);
    }

    public void onPause() {
        stopAdvertising();
        super.onPause();
    }

    public void onDestroy() {
        stopAdvertising();
        super.onDestroy();
    }

    /**
     * Starts BLE Advertising by starting {@code AdvertiserService}.
     *
     * @param addr
     */
    private void startAdvertising(String addr, String data) {
        startService(getServiceIntent(this, addr, data));
    }

    /**
     * Stops BLE Advertising by stopping {@code AdvertiserService}.
     */
    private void stopAdvertising() {
        stopService(getServiceIntent(this, null, null));
    }


    protected void onListItemClick(ListView l, View v, int position, long id) {
        BluetoothDevice device = (BluetoothDevice) leDeviceListAdapter.getItem(position);
        String addr = device.getAddress();
        String serialNumber = leDeviceListAdapter.getSerialNumber(position);
        Log.d(TAG, "onListItemClick serial " + serialNumber);
        startAdvertising(addr, serialNumber);
    }
}