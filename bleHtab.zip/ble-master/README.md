# BLE PoC - Central Htab - Peripheral Smartphone

## 1) BLE Principle

There are some usefull notes about BLE to implement this PoC.

### BLE protocole stack
![BLE protocole stack (ref: researchgate.net)](https://www.researchgate.net/publication/328541826/figure/fig1/AS:686033486217217@1540574537267/Bluetooth-Low-Energy-Protocol-Stack.ppm)


###  Link Layer (LL):

Link Layer is the part of Controller, in the firmware of bluetooth module. So an user app at Android SDK level doesn't have dirrect access to.

* Roles (1)
    *  *Advertiser*: A device sending advertising packets. 
    *  *Scanner*: A device scanning for advertising packets.
    *  *Master*: A device that initiates a connection and manages it later.
    *  *Slave*: A device that accepts a connection request and follows the master's timing.
* Device Address (1):
    *  *Public address*: This is the equivalent to a fixed factory-programmed device address. It must be registered with the IEEE registration Authority and will never change during the lifetime of the device.
    *  *Random address*: This can be preprogrammed on the device or dynamically generated at runtime. 

### Generic Access Profile (GAP):

GAP specifies how devices perform control procedures such as device discovery, connection, security establishment to ensure interoperability and to allow data exchange to take place between devices from different vendors.

* Roles (1):
    *   *Broadcaster* corresponds to the LL advertiser: A device periodically sends out advertising packets with data. The data is accessible to any device that is listening. No connection is required.
    *   *Observer* corresponds to the LL scanner: A device listens for data embedded in advertinsing packets. No connection is required.
    *   *Peripheral* corresponds to the LL slave: This role uses advertising packets to allow centrals to find it and, subsequently, to establish a connection with it. The LE protocole is optimized to require few ressources for peripheral device.
        *  *Discoverability modes*: A peripheral must be in discoverablility mode for a central to discover it. 
        *  *Connection establishment modes*: For a central to intiate a connection establishment with a peripheral, the latter must be in a connectable mode.
            *  *Non-connectable mode*: with PDU types AD_NONCONN_IND or ADV_SCAN_IND, the device is not connectable.
            *  *Directed connectable mode*: with [PDU type ADV_DIRECT_IND](https://www.bluetooth.com/blog/bluetooth-low-energy-it-starts-with-advertising/). A device sends advertising packets at a high frequecy and for a short time, with no user data payload and with a target central Bluetooth Address. There is no information how to setup this mode from SDK Android.
            *  *Undirected connectable mode*: with PDU type ADV_IND, this is the standard connectable mode. Both connectable modes implicity require the device to send the advertising packets with the itent to connect to a central.
    *   *Central* corresponds to the LL master: A device capable of establishing multiple connections. It's always the initiator of connection. The central starts by listening for other devices' advertising and then initiates a connection with the selected device. The central is usually implemented on powerful CPUs devices.
        *  *Discoverability procesdures*: A central must be in a discoverability procedure to discover a peripheral.
        *  *Connection establishment procedures*: A central must be in connection establishment procedure to connect to a peripheral.
* Device Address (1), GAP extends the concept of Random address by classifying them into three different categories:
    *  *Static address*: It's used as a replacement for public ones whenever the manufacturer doesn't want to register with IEEE. This is a random number that can e generated every time the device boots up or can stay the same for the lifetime of the device. However, it can't be changed during a power cycle of the device.
    *  *Non-resolvable private address*: Not commonly used. This is a randomly generated number. It represents a temporary address used for certain amount of time.
    *  *Resolvable private address*: It form the basis of the privacy feature. It's generated form an identity resolving key (IRK) and a random number. It can be changed often.
* Security modes and procedures: TODO. There is no security in this PoC.
    *  Security mode 1: Lvl2 , Lvl2, Lvl3
    *  Security mode 2: Lvl1, Lvl2
    *  Non-boundable mode
    *  Bondable mode
    *  Bounding procedure
    *  Autheticatation procedure
    *  Authorization procedure
    *  Encryption procedure
* GAP Service: TODO
    *  Device Name characteristic
    *  Appearance charcteristic
    *  Periperal Preferred connection Parameters characteristic
      
### Generic Attribute Profile (GATT) TODO

The GATT establishes in detail how to exchange all profile and user data over a BLE connection, which is etablished by GAP.

***Unlike the connection between LL roles and GAP roles, there is no connection between GAP roles and GATT roles. Both GAP central and GAP peripheral can act as a GATT client or server or both at the same time!***

* [GATT Microchip developper](https://microchipdeveloper.com/wireless:ble-gatt-overview)
* Data Hierarchy

![](https://microchip.wdfiles.com/local--files/wireless%3Able-gatt-data-organization/attribute-hierarchy.png)



## 2) PoC Conception:

Two types of advertising:
*  Discovery advertising: a default advertising packet with a smartphone's name.
*  Directed advertising: a default advertising packet with the selected Htab's serial number, without the smartphone's name. Because there is no space left in the advertising packet's payload.

There are two GATT servers, the first one is on the Htab and the second is on the Smartphone. Using GATT Data Hierarchy, two GATT servers are defined by:

*  GAP Center - HTab GATT server
    * Service: Generic Attribute (defaut service)
        * Characteristic: Service Changed
    * Service: Generic Access (default service)
        * Characteristic: Device Name (for getting GAP central's device name from GAP peripheral, the latter must connect to the former's GATT server then read this characteristic's value)
        * Characteristic: Appearance
        * Characteristic: Central Address Resolution
    * Service: Device Information
        * Characteristic: Serial Number String (for getting GAP central's serial number from GAP peripheral, the latter must connect to the former's GATT server then read this characteristic's value) 
*  GAP peripheral - Smartphone GATT server:
    * Service: Generic Attribute (standart service without value, it's added by system when the system creates an advertising packet)
	    * Characteristic: Service Changed
    * Service: Generic Access (standard service without value, it's added by the system when the system creates an advertising packet)
	    * Characteristic: Device Name (the value is the device name if you add it in advertising packet) 
	    * Characteristic: Appearance
	    * Characteristic: Central Address Resolution
    * Service: User Data or custom service for user authentification. This may be on GAP Center side.

The sequence diagrame for device discovery and user authentication is represented as follows:

![Sequence diagram](/images/BLEDiagram.png)


## 3) PoC Implementation:

TODO: Note some usefull implementation's information.

* Discovery: start Central and Peripheral apps. Hit scan button on Central app. There are results on 2 devices.

![Discovery - peripheral](/images/adv.png)

![Discovery - central ](/images/central.png)

* Directed connection: Select an HTable in the list on Peripheral app. Hit scan button on Central app. There is a result in Logcat of the central.

> com.example.bluetooth.le D/BLEGatt/LeScanCallback: ======== received serial: 1720b1d4ea9ceb5e my serial 1720b1d4ea9ceb5e 

## 3) Reference:

(1) [Getting Started with Bluetooth Low Energy - bluetooth 4.1](https://books.google.fr/books/about/Getting_Started_with_Bluetooth_Low_Energ.html?id=AIR7AwAAQBAJ&source=kp_book_description&redir_esc=y)

(2) https://www.researchgate.net/publication/328541826/figure/fig1/AS:686033486217217@1540574537267/Bluetooth-Low-Energy-Protocol-Stack.ppm

(3) https://www.bluetooth.com/blog/bluetooth-low-energy-it-starts-with-advertising/

(4) [Microchip developpement](https://microchipdeveloper.com/wireless:ble-gatt-overview)