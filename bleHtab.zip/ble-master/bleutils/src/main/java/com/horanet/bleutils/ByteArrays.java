package com.horanet.bleutils;

import android.util.Log;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * Created by h4 on 19/06/15.
 */
public class ByteArrays {
    private static final String TAG = ByteArrays.class.getSimpleName();

    /**
     * ByteArrays an array of bytes into a string of hex values.
     *
     * @param bytes Bytes to convert.
     * @return The bytes in hex string format.
     */
    public static String byte2HexString(byte[] bytes) {
        String ret = "";
        if (bytes != null) {
            for (Byte b : bytes) {
                ret += String.format("%02X", b.intValue() & 0xFF);
            }
        }
        return ret;
    }

    /**
     * ByteArrays an array of bytes into a string of hex values. In case of Mifare Classic, bytes[0] always store a value of Mifare Card's block[0].
     *
     * @param bytes Bytes to convert.
     * @return The bytes in hex string format.
     */
    public static String byte2HexStringReversed(byte[] bytes) {
        String ret = "";
        if (bytes != null) {

            for (int i = bytes.length - 1; i >= 0; i--) {
                Byte b = bytes[i];
                ret += String.format("%02X", b.intValue() & 0xFF);
            }
        }
        return ret;
    }

    /**
     * SRC: Mifare Classic Tool
     * ByteArrays a string of hex data into a byte array.
     * Original author is: Dave L. (http://stackoverflow.com/a/140861).
     *
     * @param s The hex string to convert
     * @return An array of bytes with the values of the string.
     */
    public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        try {
            for (int i = 0; i < len; i += 2) {
                data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                        + Character.digit(s.charAt(i + 1), 16));
            }
        } catch (Exception e) {
            Log.d(TAG, "Argument(s) for hexStringToByteArray(String s)"
                    + "was not a hex string");
        }
        return data;
    }

    public static String string2Hex(String arg) {
        //Log.d(TAG, String.format("%04x", new BigInteger(1, arg.getBytes(Charset.forName("US-ASCII")))));
        return String.format("%04x", new BigInteger(1, arg.getBytes(Charset.forName("US-ASCII"))));
    }

    // HclFat use ASCII hex value.
    public static byte[] string2byteArray(String s) {
        final String FUNC_NAME = " " + Thread.currentThread().getStackTrace()[2].getMethodName();
        String hexString = string2Hex(s);
        Log.d(TAG + FUNC_NAME, Arrays.toString(hexString.getBytes()));
        return ByteArrays.hexStringToByteArray(hexString);
    }

    public static int byteArrayToInt(byte[] bytes) {
        return ByteBuffer.wrap(bytes).getInt();
    }

    public static byte[] intToByteArray(int value) {
        return ByteBuffer.allocate(Integer.SIZE / Byte.SIZE).putInt(value).array();
    }

    /**
     * SRC: Mifare Classic Tool
     * Reverse a byte Array (e.g. Little Endian -> Big Endian).
     * Hmpf! Java has no Array.reverse(). And I don't want to use
     * Commons.Lang (ArrayUtils) from Apache....
     *
     * @param array The array to reverse (in-place).
     */
    public static void reverseByteArrayInPlace(byte[] array) {
        for (int i = 0; i < array.length / 2; i++) {
            byte temp = array[i];
            array[i] = array[array.length - i - 1];
            array[array.length - i - 1] = temp;
        }
    }

}
